from .core import Poly, monomial


x = monomial()
ONE = monomial(power=0)
MINUS_ONE = monomial(-1, 0)
TWO = monomial(2, 0)
THREE = monomial(3, 0)
